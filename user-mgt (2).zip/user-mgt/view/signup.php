<html lang="en">
<head>
    
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>StudyMate | Sign Up</title>

    <style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .container {
        display: flex;
        flex-direction: column;
        width: 80%;
        max-width: 500px;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
    }

    header h1 {
        margin: 0;
        font-size: 24px;
    }

    header a {
        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }

    .links {
        margin-top: 20px;
        display: flex;
        flex-direction: column;
    }

    .links a {
        text-decoration: none;
        font-size: 18px;
        margin-bottom: 10px;
    }
</style>
</head>


<body>

<fieldset>
<fieldset>

<header>
        <h1>StudyMate</h1>

    <nav>
        
        <a href="login.php">Login</a>
        <a href="signup.php">| Signup</a>
    </nav>
</header>

<div class="container">

        <div class="links">

        <form method="POST" action="../controller/regCheck.php" enctype="">
            Username:       <input type="text" name="username" value="" /><br><br>
            Name:           <input type="text" name="name" value="" /><br><br>
            Email:          <input type="email" name="email" value="" /> <br><br>
            Gender:         <input type="radio" name="gender" value="male" /> Male
                            <input type="radio" name="gender" value="female" /> Female
                            <input type="radio" name="gender" value="other" /> Other
                            <br><br>      
            Date of Birth:  <input type="date" name="dateofbirth" value="" /><br><br>
            Password:       <input type="password" name="password" value="" /> <br><br>   
                            <input type="submit" name="submit" value="Submit" />
                            <!-- <a href="login.php"> Login </a>  -->
        </form>    

        </div>
        </div>

</fieldset>
</fieldset>

</body>
</html>