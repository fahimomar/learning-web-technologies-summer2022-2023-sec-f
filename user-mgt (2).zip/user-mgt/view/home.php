<?php 
    session_start();

    if(!isset($_SESSION['flag'])){
       header('location: index.php'); 
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        /* Add CSS styles for the picture box */
        .picture-box {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 150px;
            height: 150px;
            border: 2px solid #000;
            overflow: hidden;
        }

        .picture-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head> 
<body>
<br><br><br><br><br><br><br><br><br><br> <div class="picture-box">
        <?php
        // Display the latest uploaded picture on the dashboard
        $pdo = new PDO('mysql:host=localhost;dbname=studymate', 'root', '');
        $stmt = $pdo->query('SELECT name, data FROM pictures ');
        $row = $stmt->fetch();
        if ($row) {
            $name = $row['name'];
            $data = $row['data'];
            $base64 = base64_encode($data);
            echo '<img src="data:image/jpeg;base64,' . $base64 . '" alt="' . $name . '">';
        }
        ?>
    </div>
        <h1>Welcome Home!</h1>

        <ul>
        <li><a href="view_profile.php">View ALL User</a></li>
        <!-- <li><a href="edit.php">Edit Profile</a></li> -->
        <li><a href="upload.php">Upload Profile Picture</a></li>
        <li><a href="deleteuser.php">Delete User</a></li>
        
        
    </ul>

        <!-- <a href="addUser.php"> Add New User</a> | 
        <a href="all_user.php"> List of User </a> |
        <a href="../controller/logout.php"> Logout </a> -->

</fieldset>
</fieldset>

</body>
</html>

