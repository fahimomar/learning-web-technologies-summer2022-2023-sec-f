<?php 
    require_once('../model/userModel.php');

    $allUser = getAllUser();

    
?>


<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>StudyMate | View ALL User </title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

        <a href="home.php"> Back </a> |

<fieldset>
<fieldset>

    <header>
    <h1>StudyMate</h1>

    <nav>
    
    <!-- <a href=>Logged in as <?php echo $_SESSION['username']; ?></a> -->
    
    <a href="../controller/logout.php"> Logout </a>
    </nav>
    </header>
        

        <table border="1">
            <tr>
                <td>ID</td>
                <td>Name</td>
                <td>Pasword</td>
                <td>Email</td>
                <td>Action</td>
            </tr>
            <?php for($i=0; $i < count($allUser); $i++){ ?>
            <tr>
                <td><?=$allUser[$i]['id']?></td>
                <td><?=$allUser[$i]['username']?></td>
                <td><?=$allUser[$i]['password']?></td>
                <td><?=$allUser[$i]['email']?></td>
                <td> 
                    <a href="edit.php?id=<?=$allUser[$i]['id']?>">Edit</a> | 
                    <a href="delete.php">Delete</a> 
                </td>
            </tr>
            <?php } ?>

        </table>

</fieldset>
</fieldset>


</body>
</html>