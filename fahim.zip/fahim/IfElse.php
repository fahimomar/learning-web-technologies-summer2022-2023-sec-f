<?php
$num = 5;
if ($num % 2 == 0) {
   echo $num . " is even.";
} else {
   echo $num . " is odd.";
}
?>