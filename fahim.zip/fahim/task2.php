<?php
$length = 10;
$width = 5;

$area = $length * $width;
$perimeter = 2 * ($length + $width);

echo "<h2>Results:</h2>";
echo "Area: " . $area . "<br>";
echo "Perimeter: " . $perimeter;
?>