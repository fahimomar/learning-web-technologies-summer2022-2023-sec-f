<!DOCTYPE html>
<html>
<head>
<title>Xcompany - Home Page</title>
<style>
header {
display: flex;
justify-content: space-between;
align-items: center;
padding: 10px;
background-color: #333;
color: #fff;
}
header h1 {
margin: 0;
font-size: 24px;
}
header a {
color: #fff;
text-decoration: none;
margin-left: 10px;
font-size: 16px;
}
</style>
</head>
<body>
<header>
<h1>Xcompany</h1>
</header>
<main>

<body>
<nav>
<a href="home.php">Home</a>
<a href="login.php">Login</a>
<a href="register.php">Register</a>
</nav>

<form method="post" action="process.php" enctype="multipart/form-data">

<fieldset>

<legend>REGISTRATION</legend>

           Name: <input type="text" name="name" value=""/> <br>

           Email: <input type="email" name="email" value=""/> <br/>

           User Name: <input type="text" name="username" value=""/> <br>

           Password: <input type="pass" name="pass" value=""/> <br>

           Confirm Password: <input type="pass" name="pass" value=""/> <br>

           




<form method="post">

<fieldset>

<legend>Gender</legend>

       

<label>

<input type="radio" name="gender" value="male" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'male' ? 'checked' : ''; ?>> Male

</label>

<label>

<input type="radio" name="gender" value="female" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'female' ? 'checked' : ''; ?>> Female

</label>

<label>

<input type="radio" name="gender" value="other" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'other' ? 'checked' : ''; ?>> Other

</label>

<br />

</fieldset>

<form method="post">

<fieldset>

<legend>Date of Birth</legend>

       D.O.B: <input type="date" name="dob" value="<?php echo $_POST['dob'] ?? ''; ?>" /> <br />





</fieldset>

           

<input type="submit" name="submit" value="Submit">

<input type="reset" name="reset" value="reset">          

</fieldset>

</form>

</body>

</html>