<!DOCTYPE html>
<html>
<head>
<title>Xcompany - Home Page</title>
<style>
header {
display: flex;
justify-content: space-between;
align-items: center;
padding: 10px;
background-color: #333;
color: #fff;
}
header h1 {
margin: 0;
font-size: 24px;
}
header a {
color: #fff;
text-decoration: none;
margin-left: 10px;
font-size: 16px;
}
</style>
</head>
<body>
<header>
<h1>Xcompany</h1>
<nav>
<a href="index.php">Home</a>
<a href="login.php">Login</a>
<a href="register.php">Register</a>
</nav>
</header>
<main>
<?php
// Check if user is logged in
session_start();
if (isset($_SESSION['username'])) {
// If logged in, show welcome message
echo "<h1>Welcome, " . $_SESSION['username'] . "!</h1>";
echo "<a href='logout.php'>Logout</a>";
} else {
// If not logged in, show login and register links
echo "<h1>Welcome to my website!</h1>";
echo "<p>Please login or register to access the site.</p>";
}
?>
</main>
</body>
</html>