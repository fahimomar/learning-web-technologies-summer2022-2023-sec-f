<!DOCTYPE html>
<html>
<head>
<title>Xcompany - Home Page</title>
<style>
header {
display: flex;
justify-content: space-between;
align-items: center;
padding: 10px;
background-color: #333;
color: #fff;
}
header h1 {
margin: 0;
font-size: 24px;
}
header a {
color: #fff;
text-decoration: none;
margin-left: 10px;
font-size: 16px;
}
</style>
</head>
<body>
<header>
<h1>Xcompany</h1>
<nav>
<a href="index.php">Home</a>
<a href="login.php">Login</a>
<a href="register.php">Register</a>
</nav>
</header>
<main>
<form method="post" action="process.php" enctype="multipart/form-data">
<title>Xcompany - Login</title>

</head>
<body>
<fieldset>
<h1>Login</h1>
<form method="post" action="login.php">
<label for="username">Username:</label>
<input type="text" id="username" name="username" required><br>

<label for="password">Password:</label>
<input type="password" id="password" name="password" required><br>

<p><a href="forgot_password.php">Forgot password?</a></p>

<input type="submit" name="submit" value="Submit">
</fieldset>
</form>
</body>
</html>