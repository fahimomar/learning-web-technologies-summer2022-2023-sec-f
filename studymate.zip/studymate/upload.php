<!DOCTYPE html>
<html>

<form action="upload.php" method="POST" enctype="multipart/form-data">
<input type="file" name="image">
<input type="submit" name="submit" value="Upload">
</form>

</html>