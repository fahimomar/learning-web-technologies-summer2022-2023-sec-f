<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'database.php';

$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Profile</title>
</head>
<body>
    <h1>View Profile</h1>


    <table>
        <tr>
            <th>Username</th>
            <td><?php echo $row['username']; ?></td>
        </tr>
        <tr>
            <th>Password</th>
            <td><?php echo $row['password']; ?></td>
        </tr>
    </table>

    <a href="edit_profile.php">Edit Profile</a>

    <br><a href="dashboard.php">Back</a>

</body>
</html>