<?php
session_start();

if (isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'database.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $dateofbirth = $_POST['dateofbirth'];

    $checkUsername = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $checkUsername);

    if (mysqli_num_rows($result) > 0) {
        $error = "Username already exists";
    } else {
        $insertUser = "INSERT INTO users (username, password, name, email, gender, dateofbirth) VALUES ('$username', '$password', '$name', '$email' , '$gender' , '$dateofbirth')";

        if (mysqli_query($conn, $insertUser)) {
            $_SESSION['username'] = $username;
            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Error creating user: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sign Up</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>
<header>
<h1>X Company</h1>

<nav>
<a href="index.php">Home</a>
<a href="login.php">| Login</a>
<a href="signup.php">| Signup</a>
</nav>
</header>

    <h1>Sign Up</h1>
    <?php if (isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post">

    <div>

        <label for="name">Name :</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="username">Username :</label>
        <input type="text" name="username" required><br><br>

        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="password">Password :</label>
        <input type="password" name="password" required><br><br>

        <label>
                Gender : <input type="radio" name="gender" value="male" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'male' ? 'checked' : ''; ?>> Male
        </label>
        <label>
                <input type="radio" name="gender" value="female" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'female' ? 'checked' : ''; ?>> Female
        </label>
        <label>
                <input type="radio" name="gender" value="other" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'other' ? 'checked' : ''; ?>> Other
        </label><br><br>


        Date of Birth : <input type="date" name="dateofbirth" value="<?php echo $_POST['dateofbirth'] ?? ''; ?>" /> <br />

        <br><br><input type="submit" value="Sign Up">
        <input type="reset" name="reset" value="reset"><br><br>
        
    </div>
    </form>
</body>
</html>