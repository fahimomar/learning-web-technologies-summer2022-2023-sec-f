<?php

// Include the database connection file
include('database.php');

// Rest of the code...

?>
<!DOCTYPE html>
<html>
<form action="group.php" method="POST">
<label for="group_name">Group Name:</label>
<input type="text" name="group_name" id="group_name">

<label for="group_description">Group Description:</label>
<textarea name="group_description" id="group_description"></textarea>

<label for="group_privacy">Group Privacy:</label>
<select name="group_privacy" id="group_privacy">
<option value="public">Public</option>
<option value="private">Private</option>
</select>

<input type="submit" name="submit" value="Create Group">
</form>
</html>

<?php
session_start();

if(isset($_POST['submit'])) {
  $group_name = $_POST['group_name'];
  $group_description = $_POST['group_description'];
  $group_privacy = $_POST['group_privacy'];
  $user_id = $_SESSION['user_id']; // assuming the user is logged in and their ID is stored in a session variable

  // connect to the database
  $conn = mysqli_connect("localhost", "root", "", "studymate");

  // check for errors
  if(mysqli_connect_errno()) {
     echo "Failed to connect to MySQL: " . mysqli_connect_error();
     exit();
  }

  // insert the group details into the database
  $sql = "INSERT INTO groups (group_name, group_description, group_privacy, user_id) VALUES ('$group_name', '$group_description', '$group_privacy', '$user_id')";
  $result = mysqli_query($conn, $sql);

  if($result) {
     // group created successfully
     echo "Group created successfully.";
  } else {
     // error creating group
     echo "Error creating group: " . mysqli_error($conn);
  }

  // close the database connection
  mysqli_close($conn);
}
?>