<?php

// Include the database connection file
include('database.php');

// Rest of the code...

?>
<!DOCTYPE html>
<html>

<form action="" method="post" enctype="multipart/form-data">
<input type="file" name="picture">
<input type="submit" value="Upload">
</form>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 $picture = $_FILES['picture'];

 // Check if file was uploaded without errors
 if ($picture['error'] == UPLOAD_ERR_OK) {
   // Store picture in SQL database
   $pdo = new PDO('mysql:host=localhost;dbname=studymate', 'root', '');
   $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $stmt = $pdo->prepare('INSERT INTO pictures (name, data) VALUES (?, ?)');
   $stmt->execute([$picture['name'], file_get_contents($picture['tmp_name'])]);
   echo 'File uploaded and stored in database successfully.';
 } else {
   echo 'Error uploading file.';
 }
}
?>