<?php
include 'db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $priority = $_POST['priority'];

    $stmt = $pdo->prepare("UPDATE requirements SET title=?, description=?, priority=? WHERE id=?");
    $stmt->execute([$title, $description, $priority, $id]);

    header("Location: index.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM requirements WHERE id=?");
$stmt->execute([$id]);
$requirement = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Requirement</title>
</head>
<body>
    <h1>Edit Requirement</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title" value="<?php echo $requirement['title']; ?>"><br>
        <label>Description:</label>
        <textarea name="description"><?php echo $requirement['description']; ?></textarea><br>
        <label>Priority:</label>
        <input type="number" name="priority" value="<?php echo $requirement['priority']; ?>"><br>
        <input type="submit" value="Save Changes">
    </form>
    <a href="index.php">Back to Dashboard</a>
</body>
</html>
