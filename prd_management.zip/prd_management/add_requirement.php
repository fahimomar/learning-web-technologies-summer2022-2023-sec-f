<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $features = $_POST['features']; // Make sure this corresponds to the input field name
    $priority = $_POST['priority'];

    $stmt = $pdo->prepare("INSERT INTO requirements (title, description, features, priority) VALUES (?, ?, ?, ?)");
    $stmt->execute([$title, $description, $features, $priority]); // Added a comma after $features

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Requirement</title>
</head>
<body>
    <h1>Add New Requirement</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title"><br>
        <label>Description:</label>
        <textarea name="description"></textarea><br>
        <label>Features:</label>
        <textarea name="features"></textarea><br>
        <label>Priority:</label>
        <input type="number" name="priority"><br>
        <input type="submit" value="Add Requirement">
    </form>
    <a href="index.php">Back to Dashboard</a>
</body>
</html>
