<?php
include 'db.php';

// Fetch requirements from the database
$stmt = $pdo->query("SELECT * FROM requirements ORDER BY priority DESC");
$requirements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>PRD Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1 {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <h1>PRD Management System - Admin Dashboard</h1>
    <a href="add_projects.php">Add New Project</a>
    <table>
        <tr>
            <th>Title</th>
            <th>Features</a></th>
            <th>Description</th>
            <th>Priority</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($requirements as $requirement): ?>
        <tr>

            <td><?php echo $requirement['title']; ?></td>
            <td><a href="add_features.php">Add new Features</td>
            <td><?php echo $requirement['description']; ?></td>
            <td><?php echo $requirement['priority']; ?></td>
            <td>
                <a href="edit.php?id=<?php echo $requirement['id']; ?>">Edit</a>
                <a href="delete.php?id=<?php echo $requirement['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
