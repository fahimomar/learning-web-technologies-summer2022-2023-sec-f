<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $priority = $_POST['priority'];

    $stmt = $pdo->prepare("INSERT INTO requirements (title, description, priority) VALUES (?, ?, ?)");
    $stmt->execute([$title, $description, $priority]);

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Project</title>
</head>
<body>
    <h1>Add New Project</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title"><br>
        <label>Features:</label>
        <input type="text" name="features"><br>
        <label>Description:</label>
        <textarea name="description"></textarea><br>
        <label>Priority:</label>
        <input type="number" name="priority"><br>
        <input type="submit" value="Add Project">
    </form>
    <a href="index.php">Back to Dashboard</a>
</body>
</html>
